# Graph Report - Roblox Gra  (2026-10-02)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 530 nodes · 1027 edges · 42 communities (28 shown, 14 thin omitted)
- Extraction: 95% EXTRACTED · 5% INFERRED · 0% AMBIGUOUS · INFERRED: 55 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Community 0
- Community 1
- Community 2
- Community 3
- Community 4
- Community 5
- Community 6
- Community 7
- Community 8
- Community 9
- Community 10
- Community 11
- Community 12
- Community 13
- Community 14
- Community 15
- Community 16
- Community 17
- Community 18
- Community 19
- Community 20
- Community 21
- Community 22
- Community 23
- Community 24
- Community 25
- Community 26
- Community 27
- Community 28
- Community 29

## God Nodes (most connected - your core abstractions)
1. `ball()` - 31 edges
2. `block()` - 19 edges
3. `cyl()` - 19 edges
4. `NumberFormat.Abbreviate()` - 18 edges
5. `ell()` - 16 edges
6. `card()` - 11 edges
7. `Cutscene.Play()` - 11 edges
8. `build()` - 11 edges
9. `mk()` - 10 edges
10. `renderCodes()` - 9 edges

## Surprising Connections (you probably didn't know these)
- `showToast()` --calls--> `NumberFormat.Abbreviate()`  [INFERRED]
  studio-snapshots/StarterGui/RNGGui/TreasureReveal.client.luau → src/ReplicatedStorage/NumberFormat.luau
- `renderAchievements()` --calls--> `A.BonusText()`  [INFERRED]
  studio-snapshots/StarterGui/RNGGui/ActivityClient.client.luau → src/ReplicatedStorage/ActivityConfig.luau
- `card()` --calls--> `ItemIcon.create()`  [INFERRED]
  studio-snapshots/StarterGui/RNGGui/RNGClient.client.luau → src/ReplicatedStorage/ItemIcon.luau
- `card()` --calls--> `NumberFormat.Abbreviate()`  [INFERRED]
  studio-snapshots/StarterGui/RNGGui/RNGClient.client.luau → src/ReplicatedStorage/NumberFormat.luau
- `card()` --calls--> `NumberFormat.Abbreviate()`  [INFERRED]
  studio-snapshots/StarterGui/RNGGui/TreasureBook.client.luau → src/ReplicatedStorage/NumberFormat.luau

## Import Cycles
- None detected.

## Communities (42 total, 14 thin omitted)

### Community 0 - "Community 0"
Cohesion: 0.06
Nodes (32): Config.VariantName(), U.Calculate(), B.Add(), B.Multipliers(), B.Permanent(), B.Personal(), B.Profile(), B.Refresh() (+24 more)

### Community 1 - "Community 1"
Cohesion: 0.17
Nodes (39): B.bell(), B.bone(), B.button(), B.candle(), B.cartridge(), B.claw(), B.cluster(), B.coin() (+31 more)

### Community 2 - "Community 2"
Cohesion: 0.10
Nodes (32): U.Available(), U.CostOf(), U.Distance(), U.LockReason(), U.Neighbours(), burst(), close(), dropCounter() (+24 more)

### Community 3 - "Community 3"
Cohesion: 0.11
Nodes (22): S.Previous(), addPrompt(), isOpen(), publish(), travel(), watch(), build(), clear() (+14 more)

### Community 4 - "Community 4"
Cohesion: 0.16
Nodes (20): R.Count(), R.Multipliers(), R.Requirement(), equippedAfterReset(), Rules.Apply(), Rules.Check(), publish(), box() (+12 more)

### Community 5 - "Community 5"
Cohesion: 0.23
Nodes (20): actionButton(), bar(), call(), card(), claim(), fetch(), header(), mk() (+12 more)

### Community 6 - "Community 6"
Cohesion: 0.11
Nodes (13): Balance.ShovelPower(), PetConfig.Multiplier(), TC.BiomeFor(), armPowers(), collect(), flush(), pct(), award() (+5 more)

### Community 7 - "Community 7"
Cohesion: 0.19
Nodes (16): A.BonusText(), A.RewardText(), NumberFormat.Abbreviate(), daily(), endEvent(), grant(), newQuests(), nice() (+8 more)

### Community 8 - "Community 8"
Cohesion: 0.14
Nodes (12): bump(), ease(), M.Play(), mk(), newScene(), smooth(), span(), eul() (+4 more)

### Community 9 - "Community 9"
Cohesion: 0.21
Nodes (17): applyMode(), bounce(), doRoll(), fovPunch(), hideStage(), itemAt(), muted(), playLandingTick() (+9 more)

### Community 10 - "Community 10"
Cohesion: 0.23
Nodes (16): bounce(), card(), closeAll(), copiesEquipped(), darken(), hidePanel(), label(), lighten() (+8 more)

### Community 11 - "Community 11"
Cohesion: 0.24
Nodes (14): card(), label(), markSeenSoon(), mk(), newCount(), newIn(), ownedIn(), render() (+6 more)

### Community 12 - "Community 12"
Cohesion: 0.23
Nodes (11): ItemIcon.create(), Cutscene.Play(), lengthOf(), play(), playDef(), shake(), shockwave(), soundFor() (+3 more)

### Community 13 - "Community 13"
Cohesion: 0.26
Nodes (14): ball(), build(), curve(), emitter(), fillHalf(), light(), mergeInto(), outline() (+6 more)

### Community 14 - "Community 14"
Cohesion: 0.28
Nodes (13): card(), copies(), eggArt(), label(), makeSign(), mk(), playHatch(), round() (+5 more)

### Community 15 - "Community 15"
Cohesion: 0.32
Nodes (13): burst(), fxPart(), hue(), lowPriority(), mk(), playSound(), pushReveal(), pushToast() (+5 more)

### Community 16 - "Community 16"
Cohesion: 0.21
Nodes (6): pick(), probe(), resolve(), split(), studioHook(), write()

### Community 17 - "Community 17"
Cohesion: 0.33
Nodes (9): finish(), makeArrow(), mk(), pointAt(), pointWorld(), run(), say(), tween() (+1 more)

### Community 18 - "Community 18"
Cohesion: 0.35
Nodes (10): hill(), load(), make(), mark(), outline(), round(), snowflake(), step() (+2 more)

### Community 19 - "Community 19"
Cohesion: 0.27
Nodes (3): isAdmin(), onPlayer(), run()

### Community 20 - "Community 20"
Cohesion: 0.60
Nodes (9): box(), diamond(), ear(), ell(), M.create(), part(), rod(), soft() (+1 more)

### Community 21 - "Community 21"
Cohesion: 0.29
Nodes (5): apply(), buildVisual(), heightOf(), lockDown(), tileCenter()

### Community 22 - "Community 22"
Cohesion: 0.33
Nodes (7): mk(), pill(), pop(), refresh(), rollsDone(), setPill(), showBanner()

### Community 23 - "Community 23"
Cohesion: 0.39
Nodes (6): applyVolume(), draw(), musicOn(), nextId(), reshuffle(), targetVolume()

### Community 24 - "Community 24"
Cohesion: 0.43
Nodes (4): A.part(), A.rod(), A.scene(), A.sprite()

### Community 25 - "Community 25"
Cohesion: 0.48
Nodes (5): setup(), spark(), swap(), tween(), value()

### Community 26 - "Community 26"
Cohesion: 0.80
Nodes (5): ball(), gem(), line(), M.create(), p()

### Community 28 - "Community 28"
Cohesion: 0.83
Nodes (3): mute(), onPlayer(), watch()

## Knowledge Gaps
- **14 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `NumberFormat.Abbreviate()` connect `Community 7` to `Community 0`, `Community 2`, `Community 3`, `Community 5`, `Community 9`, `Community 10`, `Community 11`, `Community 12`, `Community 14`, `Community 15`?**
  _High betweenness centrality (0.114) - this node is a cross-community bridge._
- **Are the 17 inferred relationships involving `NumberFormat.Abbreviate()` (e.g. with `grant()` and `rewardText()`) actually correct?**
  _`NumberFormat.Abbreviate()` has 17 INFERRED edges - model-reasoned connections that need verification._
- **Should `Community 0` be split into smaller, more focused modules?**
  _Cohesion score 0.059506531204644414 - nodes in this community are weakly interconnected._
- **Should `Community 2` be split into smaller, more focused modules?**
  _Cohesion score 0.10121457489878542 - nodes in this community are weakly interconnected._
- **Should `Community 3` be split into smaller, more focused modules?**
  _Cohesion score 0.11083743842364532 - nodes in this community are weakly interconnected._
- **Should `Community 6` be split into smaller, more focused modules?**
  _Cohesion score 0.11462450592885376 - nodes in this community are weakly interconnected._
- **Should `Community 8` be split into smaller, more focused modules?**
  _Cohesion score 0.14210526315789473 - nodes in this community are weakly interconnected._