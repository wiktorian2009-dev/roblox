# Roblox game — shared project brief

## Identity and working location

- Studio place: **money**, ID **94130990350526**.
- Canonical folder: **C:\Users\wikto\Desktop\Roblox Gra**. The Documents ca folder is historical.
- The actual game lives in Studio. Local files are a source mirror, notes, builders and selected assets; they are **not a complete place export**.
- Read the current handoff at the top of STATUS.md, then only the sources relevant to the task. Verify the connected place and current scripts before editing. Chat histories and uploaded project files do not synchronize automatically.

## Accepted direction

A bright, cartoony snow-digging/RNG simulator for kids and teens: roll shovels, dig Snow, buy upgrades, collect pets and treasures, unlock biomes and rebirth. Keep progression varied, with readable silhouettes, colorful landmarks and playful feedback.

- **Latest pacing target (2026-10-02):** fast start, slower later; World 1, ending at the Absolute Zero Portal, should take **more than 3 hours without paid boosts**. Claude's latest model includes events, daily rewards, quests and achievements: about 4 hours for an efficient engaged solo player, about 5 hours casual, about 6 hours ignoring rewards. These are model estimates, not measured human playthroughs.
- Art: simple attractive, chunky rounded 3D models; snowy ground, icy blue shadows, warm hut lighting. User requested Blender scenery across all eight World 1 stages. The AllStages pack remains prepared; consult STATUS.md before importing or replacing scenery.
- **Frostfall Village is the approved active lobby.** Preserve the archived original in ServerStorage.OldLobbyBackup.
- Only the floating egg/chances panel should have a transparent outer background. Preserve other GUI unless requested.
- The earlier egg redesign was rejected. Seven later Blender biome eggs form the current hatchable lobby display; do not reinstall rejected designs.
- User wants requested work implemented in the game, unless they explicitly request only a prompt.
- Preserve unrelated work, ownership IDs, player progress, and recoverable replacements. Do not publish or reset real player data without explicit instruction.

## Current systems — verified from Studio on 2026-10-02

| Area | Current behavior and source |
|---|---|
| World 1 balance | Stage costs: Desert 2.5K, Cursed 250K, Crystal 54M, Retro 4B, Jungle 135B, Absolute Zero 2.5T, Portal 150T Snow. Stage eggs, rebirth milestones and stage-locked upgrades were scaled with the balance pass. StageConfig / PetConfig / RebirthConfig / UpgradeConfig. |
| Upgrades | **110 tiles**, across Snow, Rolls and Misc. Explicit costs/stage locks; IDs preserve purchases. Luck tiles add percentages; shovels contribute neutral x1 luck. Balance.PowerExponent=0.63. Golden Dice starts every 10 rolls, improves to 5 (x3 luck); Rainbow starts every 100, improves to 50 (x10). |
| Rebirth | +0.50 Snow and +0.25 luck per rebirth, additive, cap 50. Resets Snow/stages/upgrades while retaining pets, shovels and discoveries. First milestone: Cursed + 62K Snow. RebirthConfig / RebirthService / RebirthRules. |
| Pets and eggs | **7 hatchable eggs, 35 pets**, including Retro/Jungle/AbsoluteZero. PetConfig / PetModels / PetService / StarterGui.RNGGui.PetClient. FrostfallVillage.EggDisplay contains the world eggs; EggFloat animates them. PetClient shows nearest odds and clones the Shell for hatching. |
| Shovel mutations | Giant: 1 in 5, x2 size/reach. Shiny: 1 in 10, x3 power. Shiny Giant combines them. RNGConfig / RNGHandler / ShovelOrbit / SnowFieldService. Index has Normal/Giant/Shiny/Shiny Giant tabs. |
| Snow fields | Workspace.SnowFieldZones defines Edit-time boxes; SnowFieldData and tiles are built during Play. SnowFields / SnowFieldService / SnowFieldClient. Sakura has its own template and two zones. |
| Buried Treasures | Fully dug tiles roll 1/100; first treasure guaranteed on the third tile. 7 biome sets, 5 rarities, 35 collection items; average Snow bonus about 6% of digging income. Collection survives rebirth. **36 PNG slots are populated** (35 treasures + menu chest). TreasureConfig / TreasureIcon / TreasureModels chest fallback / TreasureService / TreasureBook / TreasureReveal. Luck does not change these odds. Art: outputs/TreasureIcons20261001/generated-20261002/. |
| Rewards / Activities | New REWARDS left-menu button and panel with Daily, Quests, Achievements and Codes. 7-day rewards, 3 quests with a 30-minute refresh after all claims, **19 permanent-bonus achievements**, server events Snowstorm/Lucky Wind/Aurora about every 10–15 minutes. ActivityConfig / ActivityService / BoostService / ActivityClient. Codes live server-side in ActivityService. Profile fields d.Activity and d.SnowEarned; UpgradeService applies Snow/luck boosts. |
| World 2 | Sakura Garden, stage 9, opens automatically with Portal. Workspace.World2 is the 260 x 100 strip at x1565..1825, z−50..50; two 120 x 30 fields, cherry trees, lanterns, pagoda, pond/bridge, torii return portal. StageService streams and teleports; respawning in World 2 returns to its plaza. Sakura lighting profile is installed. Blender templates: ServerStorage.World2PropTemplates. Candy Kingdom is only a coming-soon gate. |
| Intro / starter shovel | About 7.9-second lobby storyboard: sky fall, landing, shovel discovery/grab, two-handed victory, close-up, gameplay handoff. Existing **Tin Shovel**, the least rare base shovel; StarterShovelRules grants it once per eligible profile and preserves better equipment. SnowIntroController / SnowIntroRig / SnowIntroArt / SnowIntroService / SnowIntro bootstrap. Skip and Studio I replay retained. ReplicatedFirst.LoadingScreen covers joining. |
| Tutorial / lobby | TutorialClient: roll, collect 10 Snow, open upgrades; prefers FrostfallSnowYard. Lobby origin (−105, 0.24, −282), spawn near (−167, 0.32, −282). FrostfallClient / FrostfallTravel / VillageOpenMenu. Cabins have repaired rear gables; paths join; snow globe uses existing Gold and Absolute Zero shovel models. |
| Upgrade UI | **UpgradeTreeClient v3**: Snow/Rolls share the main branch, Misc link/back switches pages. Owned + attached frontier + mystery ring; one-tap buying, green affordable/red unaffordable/blue owned. Larger PNG icons; preserves UpgradeTreeGui name for tutorial. Studio-only. |
| Sound | RollController has crisp prize-wheel ticks, speed-based pitch, landing click, quieter mini mode. RNGGui attributes RollTickVolume / RollTickOff control them. Studio-only; consult sound handoffs before changing asset IDs. |
| Lighting / scenery | ReplicatedFirst.BiomeLighting + Profiles grade areas, including Sakura; Lighting.BiomeGrade. FrostfallLobbyDecor / CursedStageDecor / StageDecor20260930 contain current scenery. StageDecorClient animates nearby bob/Water/Sway/Orbit/Roll props and culls distant particles. Earlier scene counts are historical; inspect current objects. |

## Source mirroring, Rojo and Graphify

The 2026-10-02 refresh captured current Edit sources: **45 scripts in game/src** for ReplicatedStorage, ServerScriptService and StarterPlayerScripts, plus **23 read-only scripts in game/studio-snapshots** for StarterGui, ReplicatedFirst, Workspace and active ServerStorage helpers. Two generic Workspace.Script copies are archive-only. The source manifest records actual classes, RunContext, paths and hashes.

- default.project.json maps only ReplicatedStorage, ServerScriptService and StarterPlayerScripts. StarterGui, Workspace, ServerStorage and ReplicatedFirst remain Studio-managed.
- A Workspace Script may use RunContext=Client; check the snapshot manifest rather than inferring execution from its filename.
- The SnowStages folder now preserves unknown Studio children so an unmapped Sakura template is retained. Existing stage economic attributes matched disk.
- Existing binary .rbxm models were not re-exported or verified. Sakura geometry/template, GUI hierarchy, lighting instances and map models remain in Studio. This folder cannot rebuild the full place.
- No active Rojo server/plugin connection was verified during this refresh. Before connecting, verify the server serves this canonical folder and review its proposed changes. Never connect the historical ca/game server or let old disk sources overwrite newer Studio work.
- **Laptop Claude chat:** its uploaded files are static copies. After a refresh, re-upload the latest PROJECT.md, STATUS.md, graphify-out/GRAPH_REPORT.md and graph.json, or use the handoff ZIP. No automatic memory sharing.
- Graphify scans game/ only. For code questions, query the scoped graph first; then verify live sources. Refresh snapshots after Studio edits, then run Refresh-Graph.ps1. A disk-only rebuild cannot capture live changes.
- Latest graph: **530 nodes, 1,027 edges, 42 communities**. Extraction warned about partial parsing in UpgradeTreeClient and PortalAnimator around Luau compound assignments. Graphify is navigation aid, not a Roblox compiler or runtime test.

## Tests, recovery and current limits

Prefer Studio tools for live changes and re-read affected sources before applying prepared patches because Claude and Codex can share the place. Workspace contains duplicate names; a dot path may be ambiguous.

For isolated progression tests, set ServerStorage.BalanceTestMode=true in **Edit before Play**, stop only your own Play session afterward, and remove the attribute in Edit. It isolates the main DataService, not every third-party system. Direct MCP module requires/test hooks can be blocked by Studio command capabilities; do not weaken those capabilities.

Latest recovery/export evidence: outputs/StudioRefresh20261002/ (live source archive, per-source hashes, before copies and sync report). Claude balance backups: ServerStorage.BalanceBackups.Before_20261002_FastStart / Before_20261002_Activities / Before_20261002_Balance_v2. Older art, lobby and intro backups remain recoverable; never blindly rerun historical builders.

Open issues and the next checks are at the top of STATUS.md. Implemented, tested, saved and published states must be stated separately.
